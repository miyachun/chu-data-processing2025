# Bee Hive Vision > 2024-11-05 3:05pm
https://universe.roboflow.com/simulatedbees/bee-hive-vision

Provided by a Roboflow user
License: CC BY 4.0

